#ifndef LED_H
#define	LED_H

#include "stm32f10x.h"

#define ON 1
#define OFF 0

extern u8 setTable[10];

#define LED1(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_8);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_8)  \

#define LED2(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_9);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_9)  \

#define LED3(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_10);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_10)  \
					
#define LED4(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_11);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_11)  \
					
#define LED5(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_12);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_12)  \

#define LED6(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_13);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_13)  \

#define LED7(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_14);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_14)  \

#define LED8(a)	if (a) \
					GPIO_SetBits(GPIOE, GPIO_Pin_15);	  \
					else							  \
					GPIO_ResetBits(GPIOE, GPIO_Pin_15)  \
					
#define SEL0(a) if (a) \
										GPIO_SetBits(GPIOB, GPIO_Pin_0); \
					else	\
						GPIO_ResetBits(GPIOB, GPIO_Pin_0); \
					
#define SEL1(a) if(a) \
									GPIO_SetBits(GPIOB, GPIO_Pin_1); \
								else \
									GPIO_ResetBits(GPIOB, GPIO_Pin_1); \
					
#define SEL2(a) if(a) \
									GPIO_SetBits(GPIOB, GPIO_Pin_2); \
								else \
									GPIO_ResetBits(GPIOB, GPIO_Pin_2);\
								
								

			
void LED_GPIO_Config(void);
void LedSel(u8 i); //0�������    1����ˮ��
void Ledx(u8 x);
void LedValue(u8 value);
void SetLedxValue(u8 x,u8 value);

					
#endif
