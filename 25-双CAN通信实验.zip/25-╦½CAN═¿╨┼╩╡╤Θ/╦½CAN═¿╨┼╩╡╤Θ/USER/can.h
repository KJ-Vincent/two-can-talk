#ifndef CAN_H
#define CAN_H

#include "stm32f10x.h"

void CAN_Config(void);
void CANSetMsg(u8 data);

extern CanTxMsg TxMsg;
extern CanRxMsg RxMsg;
extern u8 rxMsgData;

#endif
