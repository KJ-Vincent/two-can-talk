#include "led.h"

u8 setTable[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};

void LED_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE); 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_SetBits(GPIOB, GPIO_Pin_3);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15 );
	
	//���������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( GPIOB, &GPIO_InitStructure );
	GPIO_ResetBits( GPIOB, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 );
}

//ѡ��LED�����������������
void LedSel( u8 i )
{
	if( !i )
		GPIO_ResetBits( GPIOB, GPIO_Pin_3);
	else
		GPIO_SetBits( GPIOB, GPIO_Pin_3 );		
}

//���ý������������
void Ledx(u8 x)
{
	SEL2(x/4);
	SEL1(x%4/2);
	SEL0(x%2);
}

void SetLedxValue(u8 x, u8 value)
{
	Ledx(x);
	LED1(value&0x01?1:0);
	LED2(value&0x02?1:0);
	LED3(value&0x04?1:0);
	LED4(value&0x08?1:0);
	LED5(value&0x10?1:0);
	LED6(value&0x20?1:0);
	LED7(value&0x40?1:0);
	LED8(value&0x80?1:0);	
}




