#ifndef RCC_H
#define RCC_H

#include "stm32f10x.h"

void RCC_Configuration(void);

#endif
