#include "led.h"
#include "can.h"
#include "SysTick.h"
#include "KEY.h"


u8 flag = 0;
u8 txMsgData;
u8 rxMsgData;

int main()
{

	SysTick_Init();
	LED_GPIO_Config();
	Key_Config_Operation(1,1,1);
	CAN_Config();
	txMsgData = 0;
	rxMsgData = 0;
	LedSel(0);
	
	while(1)
	{
		KEY_CHECK(1,1,1);
		if( key1_flag )
		{
			key1_flag = 0;
			txMsgData++;
			if( txMsgData>99 )
				txMsgData = 0;
		}
		else if( key2_flag )
		{
			key2_flag = 0;
			if( txMsgData==0 )
				txMsgData = 99;
			else
				txMsgData--;
		}
		else if( key3_flag )
		{
			key3_flag = 0;
			//��������
			CANSetMsg(txMsgData);
			CAN_Transmit( CAN1, &TxMsg );
		}
		
		SetLedxValue( 0, setTable[rxMsgData/10] );
		Delay_us(50);
		SetLedxValue( 1, setTable[rxMsgData%10] );
		Delay_us(50);
		
		SetLedxValue( 6, setTable[txMsgData/10] );
		Delay_us(50);
		SetLedxValue( 7, setTable[txMsgData%10] );
		Delay_us(50);
	}
}


